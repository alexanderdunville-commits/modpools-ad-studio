"""Phase 3 — performance analysis (scaffolding).

The intended flow: pull campaign metrics from your ad accounts, then have Claude
summarize what's working and recommend budget/copy changes. This stub defines the
interface and the analysis prompt shape so it can be implemented later against
real metrics without touching the rest of the app.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class CampaignMetrics:
    """Normalized per-ad metrics, however they were fetched."""

    name: str
    impressions: int = 0
    clicks: int = 0
    spend: float = 0.0
    conversions: int = 0
    extra: dict = field(default_factory=dict)

    @property
    def ctr(self) -> float:
        return (self.clicks / self.impressions) if self.impressions else 0.0

    @property
    def cost_per_conversion(self) -> float:
        return (self.spend / self.conversions) if self.conversions else 0.0


def analyze(metrics: list[CampaignMetrics]) -> dict:
    """Placeholder analysis. Computes simple stats client-side today.

    To complete phase 3, send these metrics to Claude with an analyst system
    prompt and return its recommendations alongside the computed numbers.
    """
    if not metrics:
        return {"status": "no_data", "summary": "No metrics provided.", "rows": []}

    rows = [
        {
            "name": m.name,
            "ctr": round(m.ctr, 4),
            "cost_per_conversion": round(m.cost_per_conversion, 2),
            "spend": m.spend,
        }
        for m in metrics
    ]
    return {
        "status": "computed",
        "summary": (
            "Computed basic stats. Connect this to Claude for written analysis "
            "and budget/copy recommendations."
        ),
        "rows": rows,
    }
