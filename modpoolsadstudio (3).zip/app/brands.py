"""Brand profiles that ground every generated ad.

These are the single most important file to keep accurate — the model writes
copy from this context. Edit the fields below so they match how you actually
talk about each product. The more specific and truthful these are, the better
(and more on-brand) the generated ads will be.
"""

from __future__ import annotations

from .models import Brand

# NOTE: Review and edit these to match your real positioning, offers, and
# compliance rules. Anything you put in `must_avoid` will be treated as a hard
# rule the copy must respect (e.g. claims you can't legally make).
BRANDS: dict[str, Brand] = {
    "modpools": Brand(
        key="modpools",
        name="Modpools",
        tagline="The original shipping container pool.",
        description=(
            "Modpools makes premium swimming pools and spas built from "
            "shipping containers. Factory-built and arriving nearly "
            "complete, they install in days instead of the months a "
            "traditional concrete pool takes — above ground, partially "
            "in-ground, or fully in-ground, with minimal site disruption. "
            "Manufactured in North America from premium steel, with fully "
            "self-contained equipment systems. Ideal for luxury homes, "
            "vacation properties, Airbnbs, resorts, rooftop installations, "
            "and compact backyards."
        ),
        audience=(
            "Homeowners considering a pool — often fresh off an expensive "
            "quote from a traditional pool builder. Household incomes above "
            "$150,000; design-conscious; want something unique and modern; "
            "value quality and faster installation. Active on Instagram, "
            "Facebook, YouTube, Pinterest, and TikTok. Also short-term-"
            "rental hosts and vacation-property owners upgrading their "
            "listings."
        ),
        voice=(
            "Modern. Premium. Aspirational. Confident. Short sentences. "
            "Easy to read. Never sounds like a corporate brochure. Benefits "
            "over features. Creates curiosity and makes the reader imagine "
            "owning one — write like an award-winning direct-response "
            "copywriter for luxury home products."
        ),
        differentiators=[
            "Fast installation — often days instead of months",
            "Modern architectural design: clean steel lines, precise form",
            "Above-ground, partially in-ground, or fully in-ground",
            "Heated pool and spa combinations (year-round use)",
            "Acrylic viewing windows",
            "Automatic covers available",
            "Baja ledges and swim jets",
            "Smart controls — run it from your phone",
            "Minimal site disruption; your yard stays a yard",
            "Manufactured in North America, premium steel construction",
            "Fully self-contained equipment systems",
            "Fits where traditional builds can't: small yards, slopes, rooftops",
        ],
        proven_angles=[
            "Luxury Backyard — the resort at your own address; checkout time: never",
            "Fast Installation — swim this summer, not next; skip the construction saga",
            "Container Transformation — curiosity: it crossed oceans, now it's a pool",
            "Pool + Spa Combo — two waters, one footprint; the pool with no off-season",
            "Small Backyard — your yard is big enough; fits where builders said no",
            "Family Lifestyle — become the house everyone swims at; childhood doesn't wait",
            "Airbnb / Rental ROI — guests book pools; the amenity they filter for",
            "Lake House — keep the view, add the warm water",
            "Modern Architecture — designed, not dug; the pool architects choose",
            "Summer Ready — honest urgency: install calendars fill; break the 'next year' loop",
        ],
        must_avoid=[
            "Specific dollar prices or financing terms (varies by region)",
            "Guarantees about permits or install timelines for a given site",
            "Claims that it requires zero maintenance",
            "Fabricated statistics, revenue figures, or occupancy claims",
        ],
    ),
    "modpro": Brand(
        key="modpro",
        name="Modpro",
        tagline="Modular builds for professionals.",
        description=(
            "Modpro is the professional and commercial line of modular, "
            "container-based structures — built for contractors, developers, "
            "hospitality, and commercial clients who need durable, fast-to-"
            "deploy modular solutions at scale."
        ),
        audience=(
            "Contractors, property developers, hospitality operators, and "
            "commercial buyers evaluating modular builds for speed, durability, "
            "and predictable cost."
        ),
        voice=(
            "Professional, credible, and results-focused. Speaks to ROI, "
            "timelines, and durability. Less playful than Modpools, more "
            "spec-and-outcome driven."
        ),
        differentiators=[
            "Engineered for commercial-grade durability",
            "Fast deployment vs. traditional construction",
            "Predictable, modular cost structure",
            "Scales across multi-unit projects",
        ],
        must_avoid=[
            "Specific pricing or lead times without context",
            "Unverifiable performance or certification claims",
        ],
    ),
}


def get_brand(key: str) -> Brand:
    """Look up a brand by key, raising a clear error if it is unknown."""
    try:
        return BRANDS[key]
    except KeyError:
        known = ", ".join(BRANDS)
        raise KeyError(f"Unknown brand '{key}'. Known brands: {known}")


def list_brands() -> list[Brand]:
    return list(BRANDS.values())
