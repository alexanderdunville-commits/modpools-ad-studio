"""Phase 1 — ad creative generation via the Claude API.

This is the working heart of the pipeline. It takes a brand + campaign brief and
returns several distinct, ready-to-review ad variations (copy + a visual concept
for each), tailored to the target platform.
"""

from __future__ import annotations

import json

import anthropic

from . import config
from .brands import get_brand
from .models import AdSet, AdVariation, GenerateRequest, GenerateResponse

# One client for the process. Reads ANTHROPIC_API_KEY from the environment.
_client = anthropic.Anthropic()

# Per-platform guidance the model uses to fit each channel's format and norms.
PLATFORM_GUIDANCE = {
    "facebook": (
        "Facebook feed ad. Primary text ~125 chars before the fold; headline "
        "punchy (<40 chars); description short. Conversational, scroll-stopping."
    ),
    "instagram": (
        "Instagram feed/story ad. Highly visual, lifestyle-led. Short primary "
        "text, 3-6 relevant hashtags, emoji used sparingly and tastefully."
    ),
    "google_search": (
        "Google Search responsive ad. Headlines <=30 chars, descriptions <=90 "
        "chars. Keyword-aware, benefit-led, clear CTA. No hashtags or emoji."
    ),
    "google_display": (
        "Google Display ad. Short headline, concise supporting line, strong "
        "visual concept. No hashtags."
    ),
    "linkedin": (
        "LinkedIn ad. Professional, outcome- and ROI-focused. Credible tone, "
        "minimal hype, no hashtags spam (0-3 max)."
    ),
}

# Hand-written JSON schema so we get exactly the shape we want back. Every
# object sets additionalProperties:false and lists all keys as required, which
# the structured-outputs feature requires.
_AD_SCHEMA = {
    "type": "object",
    "properties": {
        "variations": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "headline": {"type": "string"},
                    "primary_text": {"type": "string"},
                    "description": {"type": "string"},
                    "call_to_action": {"type": "string"},
                    "visual_concept": {"type": "string"},
                    "hashtags": {"type": "array", "items": {"type": "string"}},
                    "rationale": {"type": "string"},
                },
                "required": [
                    "headline",
                    "primary_text",
                    "description",
                    "call_to_action",
                    "visual_concept",
                    "hashtags",
                    "rationale",
                ],
                "additionalProperties": False,
            },
        }
    },
    "required": ["variations"],
    "additionalProperties": False,
}


class GenerationError(RuntimeError):
    """Raised when the model could not produce usable ad copy."""


def _system_prompt(brand) -> str:
    differentiators = "\n".join(f"- {d}" for d in brand.differentiators)
    avoid = "\n".join(f"- {a}" for a in brand.must_avoid) or "- (none specified)"
    angles = ""
    if brand.proven_angles:
        angle_lines = "\n".join(f"- {a}" for a in brand.proven_angles)
        angles = f"""
PROVEN CAMPAIGN ANGLES (draw on these for variety — each variation should
lean on a different angle where the brief allows):
{angle_lines}
"""
    return f"""You are a senior performance-marketing copywriter producing paid
social and search ads for {brand.name}.

BRAND: {brand.name} — {brand.tagline}
WHAT IT IS: {brand.description}
DEFAULT AUDIENCE: {brand.audience}
BRAND VOICE: {brand.voice}

KEY DIFFERENTIATORS (lean on these, don't invent new ones):
{differentiators}
{angles}
HARD RULES — never violate these:
{avoid}
- Do not fabricate statistics, prices, awards, or claims not supported above.
- Each variation must be meaningfully different in angle, not a reword.
- Match the platform's format and character norms.
- Write a one-sentence `rationale` explaining the angle of each variation.

Return only the requested structured ad variations."""


def _user_prompt(req: GenerateRequest, audience: str) -> str:
    platform_note = PLATFORM_GUIDANCE.get(req.platform.value, "")
    tone = req.tone.strip() or "on-brand (use the brand voice)"
    return f"""Write {req.count} distinct ad variations.

CAMPAIGN BRIEF
- Product / offer / angle: {req.product_focus}
- Platform: {req.platform.value} — {platform_note}
- Target audience: {audience}
- Campaign goal: {req.goal}
- Tone: {tone}

For each variation provide a headline, primary_text, description,
call_to_action, a vivid visual_concept (describe the image/video an art
director would brief), hashtags (empty list when the platform doesn't use
them), and a short rationale."""


def generate(req: GenerateRequest) -> GenerateResponse:
    """Generate ad variations for a campaign brief."""
    brand = get_brand(req.brand)
    audience = req.audience.strip() or brand.audience

    try:
        message = _client.messages.create(
            model=config.MODEL,
            max_tokens=8000,
            thinking={"type": "adaptive"},
            output_config={
                "effort": config.EFFORT,
                "format": {"type": "json_schema", "schema": _AD_SCHEMA},
            },
            system=_system_prompt(brand),
            messages=[{"role": "user", "content": _user_prompt(req, audience)}],
        )
    except anthropic.APIStatusError as exc:  # surfaced cleanly to the UI
        raise GenerationError(f"Claude API error ({exc.status_code}): {exc.message}")
    except anthropic.APIConnectionError:
        raise GenerationError("Could not reach the Claude API. Check your connection.")

    if message.stop_reason == "refusal":
        raise GenerationError(
            "The model declined this request. Try rephrasing the brief."
        )

    # With output_config.format set, the first text block is valid JSON.
    text = next((b.text for b in message.content if b.type == "text"), None)
    if not text:
        raise GenerationError("The model returned no usable content.")

    try:
        ad_set = AdSet.model_validate(json.loads(text))
    except (json.JSONDecodeError, ValueError) as exc:
        raise GenerationError(f"Could not parse the model output: {exc}")

    return GenerateResponse(
        brand=brand.name,
        platform=req.platform.value,
        product_focus=req.product_focus,
        variations=ad_set.variations,
    )
