"""Application configuration, loaded from the environment."""

import os

from dotenv import load_dotenv

load_dotenv()

# The Claude model used for all generation. Opus 4.8 is the most capable model;
# see https://docs.claude.com for the current lineup.
MODEL = os.getenv("NESTLY_MODEL", "claude-opus-4-8")

# How hard the model works per request. Higher = better copy, slower + pricier.
EFFORT = os.getenv("NESTLY_EFFORT", "medium")

# The SDK reads ANTHROPIC_API_KEY from the environment automatically; we only
# surface a friendly flag here so the UI can warn when it is missing.
HAS_API_KEY = bool(os.getenv("ANTHROPIC_API_KEY"))
