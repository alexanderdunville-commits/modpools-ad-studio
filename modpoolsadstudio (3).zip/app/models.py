"""Pydantic schemas shared across the app."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class Brand(BaseModel):
    key: str
    name: str
    tagline: str
    description: str
    audience: str
    voice: str
    differentiators: list[str]
    proven_angles: list[str] = Field(
        default_factory=list,
        description="Campaign angles that fit the brand — the model draws on "
        "these when inventing variations.",
    )
    must_avoid: list[str] = Field(default_factory=list)


class Platform(str, Enum):
    facebook = "facebook"
    instagram = "instagram"
    google_search = "google_search"
    google_display = "google_display"
    linkedin = "linkedin"


class GenerateRequest(BaseModel):
    """What the web UI sends when asking for ad variations."""

    brand: str
    platform: Platform
    product_focus: str = Field(
        ...,
        description="The specific product, offer, or angle to advertise.",
        min_length=1,
    )
    audience: str = Field(
        default="",
        description="Override the brand's default audience for this campaign.",
    )
    goal: str = Field(
        default="conversions",
        description="Campaign objective, e.g. conversions, awareness, leads.",
    )
    tone: str = Field(
        default="",
        description="Optional tone override, e.g. 'bold', 'warm', 'urgent'.",
    )
    count: int = Field(default=4, ge=1, le=8)


class AdVariation(BaseModel):
    """A single ready-to-review ad concept."""

    headline: str
    primary_text: str
    description: str
    call_to_action: str
    visual_concept: str
    hashtags: list[str] = Field(default_factory=list)
    rationale: str


class AdSet(BaseModel):
    variations: list[AdVariation]


class GenerateResponse(BaseModel):
    brand: str
    platform: str
    product_focus: str
    variations: list[AdVariation]
