"""Phase 2 — publishing to ad platforms (scaffolding).

This module defines the shape of the publishing step so it can be wired up later
without reworking the rest of the app. Each adapter is a stub today: it validates
input and returns a clear "not configured" result instead of calling a live ad
API. To go live, implement the `publish` methods against the Meta Marketing API
and Google Ads API (each needs OAuth credentials + an ad account ID).
"""

from __future__ import annotations

from dataclasses import dataclass

from .models import AdVariation


@dataclass
class PublishResult:
    platform: str
    status: str  # "published" | "not_configured" | "error"
    detail: str
    external_id: str | None = None


class AdPublisher:
    """Base interface every platform adapter implements."""

    platform = "base"

    def is_configured(self) -> bool:
        return False

    def publish(self, variation: AdVariation, **kwargs) -> PublishResult:
        if not self.is_configured():
            return PublishResult(
                platform=self.platform,
                status="not_configured",
                detail=(
                    f"{self.platform} publishing is not configured yet. Add API "
                    "credentials and implement the adapter to enable it."
                ),
            )
        raise NotImplementedError


class MetaAdsPublisher(AdPublisher):
    """Facebook + Instagram, via the Meta Marketing API (to implement)."""

    platform = "meta"


class GoogleAdsPublisher(AdPublisher):
    """Google Search + Display, via the Google Ads API (to implement)."""

    platform = "google"


def get_publisher(platform: str) -> AdPublisher:
    if platform in ("facebook", "instagram"):
        return MetaAdsPublisher()
    if platform in ("google_search", "google_display"):
        return GoogleAdsPublisher()
    return AdPublisher()
