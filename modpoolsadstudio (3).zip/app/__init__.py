"""Nestly — AI ad automation for Modpools and Modpro."""

__version__ = "0.1.0"
