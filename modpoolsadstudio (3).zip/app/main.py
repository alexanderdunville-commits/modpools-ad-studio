"""FastAPI app: serves the web UI and the generation API."""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from . import config
from .brands import list_brands
from .generator import GenerationError, generate
from .models import GenerateRequest, GenerateResponse

app = FastAPI(title="Nestly — AI Ad Automation", version="0.1.0")

STATIC_DIR = Path(__file__).parent / "static"


@app.get("/api/health")
def health() -> dict:
    return {
        "status": "ok",
        "model": config.MODEL,
        "api_key_configured": config.HAS_API_KEY,
    }


@app.get("/api/brands")
def brands() -> dict:
    return {
        "brands": [
            {
                "key": b.key,
                "name": b.name,
                "tagline": b.tagline,
                "audience": b.audience,
            }
            for b in list_brands()
        ]
    }


@app.post("/api/generate", response_model=GenerateResponse)
def api_generate(req: GenerateRequest) -> GenerateResponse:
    if not config.HAS_API_KEY:
        raise HTTPException(
            status_code=503,
            detail="ANTHROPIC_API_KEY is not set. Add it to your .env file.",
        )
    try:
        return generate(req)
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    except GenerationError as exc:
        raise HTTPException(status_code=502, detail=str(exc))


@app.get("/")
def index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")


# Serve the rest of the static assets (none required today, but keeps room for
# CSS/JS files as the UI grows).
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
