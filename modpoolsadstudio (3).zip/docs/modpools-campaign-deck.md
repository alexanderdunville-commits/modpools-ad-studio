# Modpools — Master Campaign Deck

**Prepared for:** Modpools Marketing
**Scope:** 10 full campaigns · paid social + search + video + Pinterest · A/B testing playbook
**Positioning line:** *Sell the transformation, not the container.*

---

## Creative Strategy (read first)

**The three master angles — every campaign leans on one:**

1. **TIME** — Traditional pools take months and wreck your yard. A Modpool arrives nearly complete and installs in days. This is the strongest direct-response angle because the pain (construction quotes, timelines) is fresh for anyone shopping.
2. **DESIGN** — This is not a budget alternative. It's an architectural object: steel, glass, clean lines. Luxury buyers need permission to want a "container pool" — design-forward framing gives it to them.
3. **ACCESS** — Pools felt out of reach: too expensive, yard too small, too much disruption. Modpools reopens the door. ("Your yard is big enough. Your summer is soon enough.")

**Voice rules applied throughout:** short sentences · benefits over features · curiosity before explanation · never brochure-speak · let the reader picture ownership before we ask for the click.

**Compliance guardrails applied:** no specific prices, no fabricated statistics or revenue claims, no per-site permit or install-date guarantees. Urgency is framed around real seasonality (install calendars, summer) rather than invented countdowns.

---

# CAMPAIGN 1 — Luxury Backyard
### *"The Resort Is Your Address"*

**Angle:** Design + self-reward. | **Emotional trigger:** Status and earned indulgence — *I've worked for this.* | **Pain point:** Luxury always feels rented; vacations end. | **Objection addressed:** "A container pool can't be luxurious." Countered with materials, glass, lighting, and architectural framing.

**Scroll-stopping hook:**
> Your backyard is the best resort you've never stayed at.

**Primary headline:**
> Five-star nights. Zero checkout.

**Supporting copy:**
> Heated water. Architectural steel. A glass wall that glows after dark. The resort you keep flying to? Build it twenty feet from your kitchen.

**Facebook/Instagram primary text:**
> You know that first step into the pool on vacation — warm water, good light, nowhere to be? That feeling now has a permanent address. Modpools are architectural pools and spas, factory-built and installed in days, not months. Heated. Smart-controlled. Finished with an acrylic window that turns evening swims into something you'll photograph badly and remember perfectly. Stop renting the feeling.

**Short version:**
> The resort, relocated. Heated pool + spa, installed in days. Design yours.

**CTA:** *Design Your Modpool*

**Visual/video concept:** Dusk. Steam rising off lit water. Through the acrylic window, a swimmer glides past in silhouette. Cut to a couple with drinks on the Baja ledge, house lights warm behind them. Text overlay: "Checkout time: never."

**5 Facebook headlines:**
1. Five-Star Nights. Zero Checkout.
2. The Resort Is Your Address Now
3. Vacation Mode: Permanent
4. Warm Water. Twenty Feet Away.
5. Stop Renting This Feeling

**5 Instagram captions:**
1. Checkout time: never. 🌙
2. The best resort you'll ever book is behind your own house.
3. Warm water, good light, nowhere to be.
4. We moved the vacation. You're welcome.
5. Some people fly to this. You'll walk to it.

**5 Google headlines (≤30 char):**
1. The Backyard Resort
2. Luxury Container Pools
3. Heated Pool + Spa At Home
4. Resort Living, Home Address
5. Design-Forward Pools

**5 Google descriptions (≤90 char):**
1. Factory-built luxury pools with heat, spa seating & smart controls. Installed in days.
2. The architectural pool: steel, glass, glowing water. Design yours with Modpools.
3. Heated pool + spa combos that install in days, not months. Premium steel construction.
4. Resort-grade water at your own address. Explore Modpools' design options.
5. Acrylic windows. Baja ledges. Smart controls. The modern pool, delivered.

**5 YouTube pre-roll hooks (first 5 seconds):**
1. "This isn't a resort. It's a Tuesday."
2. "The most expensive part of your vacation is that it ends."
3. "Warm water, glass wall, your backyard. Keep watching."
4. "You've swum in pools like this. You've just never owned one."
5. "What if checkout time was never?"

**5 TikTok hooks:**
1. "POV: it's 9pm on a Wednesday and you're doing this." *(steam, lit pool)*
2. "Rating my backyard like it's a 5-star resort. It wins."
3. "We stopped booking pool villas. Here's why."
4. "The glow-up your backyard has been waiting for."
5. "Things in my house that feel illegal: this window." *(underwater shot)*

**5 Pinterest headlines:**
1. Modern Backyard Resort Ideas
2. Heated Pool + Spa Design Inspiration
3. The Luxury Pool That Installs in Days
4. Backyard Oasis: Container Pool Edition
5. Evening Pool Lighting Done Right

---

# CAMPAIGN 2 — Fast Installation
### *"Swim This Summer, Not Next"*

**Angle:** TIME. | **Emotional trigger:** Impatience + relief — skip the saga. | **Pain point:** Traditional pool builds mean months of noise, mud, and waiting. | **Objection addressed:** "Pools take forever and destroy your yard." The build happens in our factory, not your lawn.

**Scroll-stopping hook:**
> A traditional pool takes months of construction. This one arrived on a truck Thursday.

**Primary headline:**
> Months of excavation — or one delivery day?

**Supporting copy:**
> Your Modpool is built in our factory while your yard stays a yard. It arrives nearly complete, sets in place, and connects in days. The longest part is deciding what to grill first.

**Facebook/Instagram primary text:**
> Here's what a traditional pool build looks like: excavators, months of mud, a fence around a hole where your lawn used to be. Here's what a Modpool install looks like: a crane, an afternoon, and water by the weekend-ish. The pool is factory-built and fully self-contained — plumbing, heating, controls — before it ever sees your address. Minimal site disruption. Maximum cannonball readiness.

**Short version:**
> Built in a factory. Installed in days. Swim this summer, not next.

**CTA:** *Get Your Install Timeline*

**Visual/video concept:** Timelapse split-screen. Left: a traditional pool site — dirt, delays, tarps, seasons changing. Right: crane lowers a Modpool into place, water fills, kids jump in. Caption: "Same summer. Very different summers."

**5 Facebook headlines:**
1. Installed In Days. Not Months.
2. Your Pool Arrives On A Truck
3. Skip The Construction Saga
4. Swim This Summer, Not Next
5. One Crane Day > Six Month Build

**5 Instagram captions:**
1. Delivery day > demolition season.
2. The pool was built before it ever saw our address.
3. From flatbed to first swim, fast.
4. Our lawn survived. The pool arrived. Everybody wins.
5. Watch a summer show up on a crane. 🏗️

**5 Google headlines (≤30 char):**
1. Pools Installed In Days
2. Skip Months Of Construction
3. Factory-Built Pools
4. Fast Pool Installation
5. Swim Sooner With Modpools

**5 Google descriptions (≤90 char):**
1. Factory-built pools that arrive nearly complete. Days to install, not months.
2. No excavation saga. Minimal site disruption. Your yard stays a yard.
3. Self-contained pool systems, delivered and placed. Get your timeline today.
4. Traditional builds take months. Modpools install in days. See how it works.
5. Crane day beats construction season. Explore fast pool installation.

**5 YouTube pre-roll hooks:**
1. "This pool was installed in less time than it takes to get a contractor to call you back."
2. "Watch a swimming pool show up on a truck."
3. "Six months of construction? We did it in days. Here's the footage."
4. "Your neighbor's pool build is entering month seven. Yours could be full."
5. "Don't skip this if you've ever gotten a pool quote."

**5 TikTok hooks:**
1. "Day 1: truck. Day 2: crane. Day 3: cannonball." *(fast cuts)*
2. "Things that took longer than installing our pool: our sofa delivery."
3. "POV: your pool arrives before your neighbor's permits do."
4. "The crane video you didn't know you needed."
5. "We timed the install. You won't believe the number." *(reveal on screen)*

**5 Pinterest headlines:**
1. Pools That Install in Days
2. Fast Backyard Pool Ideas
3. No-Excavation Pool Options
4. Modular Pool Installation Explained
5. Get Pool-Ready Before Summer

---

# CAMPAIGN 3 — Shipping Container Transformation
### *"It Crossed Oceans. Now It Holds Yours."*

**Angle:** Curiosity + novelty. | **Emotional trigger:** Delight and the story you get to tell guests. | **Pain point:** Pools are generic; buyers want something with a story. | **Objection addressed:** "It's just a shipping container." It's premium steel — engineered, transformed, and unrecognizable in the best way.

**Scroll-stopping hook:**
> This steel crossed the Pacific a dozen times. Now it's the nicest thing in the neighborhood.

**Primary headline:**
> From cargo to cannonballs.

**Supporting copy:**
> A shipping container is one of the strongest structures humans mass-produce. We take that steel and turn it into a heated, glass-walled, smart-controlled pool. Every Modpool has a past life. Yours starts now.

**Facebook/Instagram primary text:**
> Everyone asks the same question at the first pool party: "Wait — it was a WHAT?" A shipping container. Corten steel built to survive oceans, re-engineered into a heated pool and spa with an acrylic viewing window and smartphone controls. It's the pool with a backstory — and the only renovation project that shows up finished.

**Short version:**
> Born a shipping container. Reborn as the best seat in your backyard.

**CTA:** *See The Transformation*

**Visual/video concept:** Rapid transformation edit: raw container in a shipyard → factory fabrication sparks → glass window install → crane set → glowing pool at night, friends laughing. End card: "Every Modpool has a past life."

**5 Facebook headlines:**
1. From Cargo To Cannonballs
2. It Was A What?!
3. The Pool With A Past Life
4. Steel Built For Oceans
5. The Ultimate Transformation

**5 Instagram captions:**
1. Every Modpool has a past life. 🌊
2. It crossed oceans. Now it holds ours.
3. The best "before and after" we've ever posted.
4. Built to survive the sea. Retired to your backyard.
5. Wait — it was a WHAT?

**5 Google headlines (≤30 char):**
1. Shipping Container Pools
2. The Original Container Pool
3. From Container To Pool
4. Premium Steel Pools
5. Container Pool + Spa Combos

**5 Google descriptions (≤90 char):**
1. The original shipping container pool. Premium steel, heated, smart-controlled.
2. Ocean-grade steel, transformed into architectural pools. See the process.
3. Container pools with acrylic windows, spa seating & fast installation.
4. Every Modpool has a past life. Design the next chapter of yours.
5. Engineered from container steel. Finished like a resort. Explore Modpools.

**5 YouTube pre-roll hooks:**
1. "This was a shipping container. Give me 15 seconds to prove it."
2. "The strongest structure in your backyard used to cross oceans."
3. "We turn cargo containers into THIS."
4. "Your pool has a construction story. Ours has a shipping manifest."
5. "Before: cargo. After: keep watching."

**5 TikTok hooks:**
1. "Telling guests our pool used to be a shipping container and filming their reaction."
2. "Before/after but make it 40 tons of steel."
3. "Things that used to be something else: my pool goes first."
4. "It survived the ocean. Now it's surviving my kids."
5. "The transformation video the algorithm owes you."

**5 Pinterest headlines:**
1. Shipping Container Pool Ideas
2. Container Pool Before & After
3. Industrial-Modern Backyard Pools
4. Upcycled Luxury: Container Pools
5. Container Pool Design Inspiration

---

# CAMPAIGN 4 — Pool + Spa Combo
### *"Two Waters. One Footprint."*

**Angle:** Year-round indulgence. | **Emotional trigger:** Having it all — summer AND winter. | **Pain point:** A pool you use 3 months a year feels like a bad deal. | **Objection addressed:** "Pools sit unused most of the year." The spa side makes it a 12-month purchase.

**Scroll-stopping hook:**
> July: it's a pool. January: it's a hot tub. Every month: it's the reason you're late.

**Primary headline:**
> Summer pool. Winter spa. Zero compromise.

**Supporting copy:**
> One Modpool, two temperatures. Swim laps in August, soak under snowfall in February. The divider keeps the spa hot and the pool cool — and your smartphone runs it all.

**Facebook/Instagram primary text:**
> The problem with pools: three great months, nine months of staring at a cover. The Modpools pool + spa combo fixes the math. One side swims, one side soaks, and the whole thing runs from your phone. Snow on your shoulders, steam off the water, and suddenly February is your favorite month. This is the pool that never goes out of season.

**Short version:**
> One footprint. Two temperatures. Twelve months of reasons.

**CTA:** *Explore Pool + Spa Combos*

**Visual/video concept:** Same fixed camera angle, four seasons morphing: summer cannonballs → autumn leaves + evening soak → winter steam and snowflakes → spring morning laps. Text: "Open all year."

**5 Facebook headlines:**
1. Summer Pool. Winter Spa.
2. The Pool That Never Closes
3. Two Waters. One Footprint.
4. February Just Got Interesting
5. Twelve Months. Zero Covers.

**5 Instagram captions:**
1. Snow on your shoulders. Steam off the water. ❄️
2. Our pool doesn't do off-seasons.
3. One side swims. One side soaks. Everyone stays.
4. February: unexpectedly undefeated.
5. Why choose between a pool and a hot tub? We didn't.

**5 Google headlines (≤30 char):**
1. Pool + Spa In One
2. Year-Round Pool & Spa
3. Heated Pool + Hot Tub Combo
4. Swim Summer, Soak Winter
5. The 12-Month Pool

**5 Google descriptions (≤90 char):**
1. Pool + spa combos in one steel footprint. Swim in July, soak in January.
2. Heated, divided, smart-controlled. The pool that never goes out of season.
3. Why pick pool or hot tub? Modpools combos do both, installed in days.
4. Two temperatures, one design. Explore year-round pool + spa combos.
5. Winter soaks, summer swims, phone-controlled. See combo options.

**5 YouTube pre-roll hooks:**
1. "Most pools work three months a year. Watch what this one does in January."
2. "It's snowing in this video. Nobody's getting out."
3. "Pool or hot tub? Wrong question."
4. "Half of this pool is 88 degrees. Guess which half."
5. "Your pool has an off-season. Ours doesn't."

**5 TikTok hooks:**
1. "Hot tub side vs pool side: the house divides." *(family split-screen)*
2. "POV: it's snowing and you're in the pool anyway."
3. "The divider that ends every pool-vs-hot-tub argument."
4. "Rating my pool in February. Still a 10."
5. "Winter said stay inside. The spa side said otherwise."

**5 Pinterest headlines:**
1. Pool and Hot Tub Combo Ideas
2. Year-Round Backyard Pool Design
3. Winter Hot Tub Aesthetic
4. Small-Footprint Pool + Spa Layouts
5. Four-Season Backyard Inspiration

---

# CAMPAIGN 5 — Small Backyard
### *"Big Enough."*

**Angle:** ACCESS. | **Emotional trigger:** Vindication — being told "no" and finding out the answer was yes. | **Pain point:** Small or sloped yards get rejected by traditional pool builders. | **Objection addressed:** "My yard is too small/too sloped for a pool." Modpools' compact modular footprint fits where builds can't.

**Scroll-stopping hook:**
> They said your yard was too small for a pool. They measured wrong.

**Primary headline:**
> Your yard is big enough. It always was.

**Supporting copy:**
> A Modpool's clean modular footprint fits where excavators can't even park — compact yards, sloped lots, tight city gardens, even rooftops. Swim jets turn short water into long workouts. Small yard. Full-size summer.

**Facebook/Instagram primary text:**
> Here's a secret the pool industry doesn't lead with: most "your yard won't work" verdicts are about their equipment, not your property. A Modpool arrives as one clean, self-contained unit — above ground, in ground, or on the slope everyone said was hopeless. Add swim jets and your compact pool becomes an endless one. The yard was never the problem.

**Short version:**
> Small yard. Sloped lot. Rooftop. A Modpool fits where pools couldn't.

**CTA:** *See If Your Yard Fits*

**Visual/video concept:** Drone pulls back from a gorgeous compact urban backyard — pool glowing, every inch used beautifully. Then a series of quick "impossible" installs: slope, rooftop, narrow lot. Text: "Big enough."

**5 Facebook headlines:**
1. Your Yard Is Big Enough
2. Small Yard. Full-Size Summer.
3. The Pool For "Impossible" Yards
4. Sloped Lot? Perfect.
5. They Measured Wrong

**5 Instagram captions:**
1. The yard was never the problem.
2. Small yard, full-size summer. 📐
3. Three pool builders said no. The crane said yes.
4. Every inch, earning its keep.
5. Rooftops, slopes, city gardens — we fit.

**5 Google headlines (≤30 char):**
1. Pools For Small Backyards
2. Small Yard? Pool Approved.
3. Compact Modern Pools
4. Pools For Sloped Lots
5. Plunge Pools With Swim Jets

**5 Google descriptions (≤90 char):**
1. Compact, self-contained pools for small yards, slopes & rooftops. Installed in days.
2. Told your yard won't work? Modpools fit where traditional builds can't.
3. Small footprint, full summer. Swim jets turn compact pools into endless ones.
4. Above ground, in ground or on a slope — see if your yard fits a Modpool.
5. City garden? Tight lot? Explore compact luxury pools from Modpools.

**5 YouTube pre-roll hooks:**
1. "Three pool companies rejected this backyard. Watch what we did with it."
2. "This yard is small. This pool doesn't care."
3. "If a builder said your yard won't work — don't skip this."
4. "There's a full pool and spa in this video. Find the yard."
5. "Sloped lot, tight access, big summer. Here's how."

**5 TikTok hooks:**
1. "Pool companies said our yard was too small. So we did this."
2. "Rating 'impossible' yards we've put pools in."
3. "The crane doesn't care about your fence line."
4. "Small yard tour, but there's a plot twist." *(reveal pool)*
5. "Swim jets on. Suddenly my 20-foot pool is endless."

**5 Pinterest headlines:**
1. Small Backyard Pool Ideas
2. Pools for Sloped Yards
3. Compact Plunge Pool Design
4. City Backyard Pool Inspiration
5. Rooftop Pool Ideas That Work

---

# CAMPAIGN 6 — Family Lifestyle
### *"The Sound Of Summer"*

**Angle:** Time + memory. | **Emotional trigger:** Kids grow up fast; make the house the destination. | **Pain point:** Screens indoors, summers slipping by, driving to other people's pools. | **Objection addressed:** "Is it worth it?" Reframed: you're not buying water, you're buying where your kids' friends hang out.

**Scroll-stopping hook:**
> Your kids will remember two things about this house. Make one of them the pool.

**Primary headline:**
> Become the house everyone swims at.

**Supporting copy:**
> Cannonball contests. Goggle marks. Towels on every chair. A Modpool installs in days and turns your backyard into the place summer actually happens — with heated water that stretches the season and smart controls that give you one less thing to manage.

**Facebook/Instagram primary text:**
> There's a version of summer where the kids are inside and the pool is at someone else's house. And there's the version where your backyard is the one they all bike to. Heated water for early June and late September. A Baja ledge for the little ones. Your phone runs the temperature; the kids run everything else. Installed in days — because childhood doesn't wait for construction season.

**Short version:**
> Be the house everyone swims at. Installed in days, loved for years.

**CTA:** *Start Your Family's Pool*

**Visual/video concept:** Golden-hour home video aesthetic: cannonball splash frozen mid-air, wet footprints on the deck, a pile of bikes on the lawn, parents unbothered on the ledge. Audio: just kids laughing. Text: "The sound of summer."

**5 Facebook headlines:**
1. Become The Pool House
2. Childhood Doesn't Wait
3. The Sound Of Summer, Daily
4. Where Their Friends Bike To
5. Make Home The Destination

**5 Instagram captions:**
1. The bikes on the lawn tell the story. 🚲
2. Goggle marks all summer. Worth it.
3. We became the house everyone swims at.
4. Childhood is short. Install accordingly.
5. The only screen out here is the pool cover.

**5 Google headlines (≤30 char):**
1. Family Pools, Fast Install
2. The Backyard Kids Bike To
3. Heated Family Pools
4. Safe, Smart Family Pools
5. Make Home The Destination

**5 Google descriptions (≤90 char):**
1. Heated family pools with auto covers & smart controls. Installed in days.
2. Become the house every kid bikes to. Family-ready Modpools, delivered.
3. Baja ledges for little ones, swim jets for big ones. Design your family pool.
4. Childhood doesn't wait for construction season. Pools installed in days.
5. Automatic covers, heated water, phone controls. Family pools made simple.

**5 YouTube pre-roll hooks:**
1. "Your kids have about ten summers left at home. Skip ad, or don't."
2. "This is what a backyard sounds like after the pool arrives."
3. "We counted: eleven kids, four towels, one very good decision."
4. "The pool went in Friday. The bikes showed up Saturday."
5. "Warning: your house is about to become the hangout."

**5 TikTok hooks:**
1. "Day 30 of being the pool house: the bikes multiply."
2. "POV: your kid's entire friend group found out about the pool."
3. "The cannonball contest has entered its fourth hour."
4. "Things I don't miss: driving to other people's pools."
5. "Adding 'lifeguard' to my parenting resume." *(Baja ledge nap shot)*

**5 Pinterest headlines:**
1. Family Backyard Pool Ideas
2. Kid-Friendly Pool Design
3. Pools with Tanning Ledges for Families
4. Backyard Summer Hangout Inspiration
5. Safe Modern Pools for Families

---

# CAMPAIGN 7 — Airbnb ROI
### *"The Amenity That Books Itself"*

**Angle:** ROI positioning. | **Emotional trigger:** Smart-money pride — an upgrade that works. | **Pain point:** Listings blend together; occupancy dips outside peak season. | **Objection addressed:** "It's an expense." Reframed: it's the photo guests filter for — and the reason they pick your listing over the one down the road.

**Scroll-stopping hook:**
> Guests don't book houses. They book pools.

**Primary headline:**
> Your listing's new first photo.

**Supporting copy:**
> "Pool" is one of the most-searched amenity filters in short-term rentals. A heated Modpool makes your property the one that stands out in a sea of lookalike listings — and installs in days, so you're not blocking your calendar for a construction season.

**Facebook/Instagram primary text:**
> Scroll any short-term rental app: the listings that stop thumbs have water in the first photo. A Modpool gives your property that photo — heated, glass-windowed, glowing at dusk — without months of construction blocking your bookings. Fast install, minimal site disruption, and a spa side that keeps the amenity earning in shoulder season. Hosts upgrade a lot of things. Few upgrades change the search result.

**Short version:**
> The amenity guests filter for. Installed in days, not booked-out months.

**CTA:** *Talk To Us About Your Property*

**Visual/video concept:** Phone-screen UI mock: thumb scrolling lookalike listings, stops hard on the one with a glowing Modpool. Cut to real dusk footage of the pool, then back to the phone: "Reserve" tapped. Text: "Guests book pools."

**5 Facebook headlines:**
1. Guests Book Pools
2. Your Listing's New First Photo
3. Stand Out In The Search Grid
4. The Amenity Guests Filter For
5. Upgrade The Thing They Search

**5 Instagram captions:**
1. The first photo does the heavy lifting. 📸
2. Guests don't book houses. They book pools.
3. Shoulder season called. The spa side answered.
4. One amenity changed the whole search result.
5. Make yours the listing they screenshot.

**5 Google headlines (≤30 char):**
1. Pools For Rental Properties
2. Airbnb Pool Installation
3. The Amenity Guests Want
4. Fast Pools For STR Hosts
5. Upgrade Your Listing

**5 Google descriptions (≤90 char):**
1. Heated pools for short-term rentals. Installed in days — not booked-out months.
2. Give your listing the first photo guests stop on. Fast, factory-built pools.
3. Pool + spa combos that keep earning in shoulder season. Talk to Modpools.
4. Minimal site disruption for busy rental calendars. Explore host options.
5. The amenity guests filter for, installed in days. Get property details.

**5 YouTube pre-roll hooks:**
1. "Host tip: guests don't book houses. They book pools."
2. "Every listing on this street looks the same. Except one."
3. "The upgrade that shows up in search filters."
4. "Your calendar can't afford a six-month construction project. Good news."
5. "What do the top listings in your market have in common? Scroll and see."

**5 TikTok hooks:**
1. "Airbnb hosts: this is the amenity guests actually search for."
2. "Rating rental upgrades: new towels, hot take, then THIS."
3. "POV: your listing just got its new first photo."
4. "The search filter that decides your occupancy."
5. "Installed in days so the calendar barely blinked."

**5 Pinterest headlines:**
1. Airbnb Backyard Upgrade Ideas
2. Vacation Rental Pool Inspiration
3. Amenities Guests Search For
4. Short-Term Rental Curb Appeal
5. Host-Smart Pool Ideas

---

# CAMPAIGN 8 — Lake House
### *"The Lake Is Beautiful. The Pool Is Warm."*

**Angle:** Vacation-property upgrade. | **Emotional trigger:** Perfecting an already-good thing. | **Pain point:** The lake is cold, weedy, or busy exactly when you want to swim. | **Objection addressed:** "We already have waterfront — why a pool?" Because the view and the swim are two different purchases.

**Scroll-stopping hook:**
> The lake is for the view. The Modpool is for actually getting in.

**Primary headline:**
> Waterfront, meet warm water.

**Supporting copy:**
> Cold lake mornings and perfect lake sunsets can coexist with an 88-degree* pool ten steps from the dock. Heated, self-contained, and installed in days — even at properties a concrete truck will never reach. (*Set your own number. It's your phone.)

**Facebook/Instagram primary text:**
> Every lake house has the same secret: nobody actually swims in the lake after Labor Day. Keep the view. Add the swim. A Modpool arrives nearly complete — no excavation crews on your cottage road, no construction summer lost — and gives you warm water with a lake panorama behind it. Spa side on for October. Dock still undefeated for coffee.

**Short version:**
> Keep the view. Add the warm water. Lake house, completed.

**CTA:** *Complete Your Lake House*

**Visual/video concept:** Wide shot: misty lake at dawn, gorgeous and clearly freezing. Pan to a steaming Modpool on the deck, someone swimming laps with the lake as backdrop. Text: "The view stays. The shivering goes."

**5 Facebook headlines:**
1. Waterfront, Meet Warm Water
2. The Lake Is For The View
3. Lake House, Completed
4. Swim Season: Extended
5. Warm Water, Lake Panorama

**5 Instagram captions:**
1. The lake is for the view. This is for the swim. 🌲
2. Dock coffee, then heated laps. Lake house perfected.
3. Nobody swims in the lake after Labor Day. Now we don't have to.
4. Keep the panorama. Lose the cold shock.
5. October at the cabin just changed forever.

**5 Google headlines (≤30 char):**
1. Pools For Lake Houses
2. Cottage & Cabin Pools
3. Heated Pools, Remote Sites
4. Lake House Pool Ideas
5. Warm Water At The Cabin

**5 Google descriptions (≤90 char):**
1. Self-contained heated pools for lake houses & cabins. Delivered nearly complete.
2. Keep the lake view, add the warm swim. Fast installs at remote properties.
3. No concrete trucks on the cottage road. Modpools arrive ready to place.
4. Extend cabin swim season into fall with a heated pool + spa combo.
5. The lake house upgrade guests remember. Explore Modpools.

**5 YouTube pre-roll hooks:**
1. "Confession from a lake house owner: we never swim in the lake."
2. "The water behind this pool is freezing. The water in it isn't."
3. "Your cottage road has never seen a concrete truck. It won't have to."
4. "Lake view. Pool temperature. Both, actually."
5. "This is what October at the cabin looks like now."

**5 TikTok hooks:**
1. "POV: the lake is 58° and your pool is whatever you typed into your phone."
2. "Lake house owners, be honest: when did you last swim in the lake?"
3. "The crane made it up the cottage road. Everything changed."
4. "Dock for coffee. Pool for swimming. System perfected."
5. "Fall at the cabin used to end the swimming. Used to."

**5 Pinterest headlines:**
1. Lake House Pool Ideas
2. Cabin Backyard Upgrades
3. Cottage Pool & Spa Inspiration
4. Waterfront Home Pool Design
5. Fall Swimming at the Lake House

---

# CAMPAIGN 9 — Modern Architecture
### *"The Pool Architects Choose"*

**Angle:** DESIGN. | **Emotional trigger:** Taste — owning the considered choice. | **Pain point:** Traditional pools are shapeless blue blobs that fight the house's design. | **Objection addressed:** "Will it look cheap?" Countered head-on: steel, glass, precise geometry — it's the most architectural object in the yard.

**Scroll-stopping hook:**
> Concrete pools are dug. This one was designed.

**Primary headline:**
> Geometry your architect will approve of.

**Supporting copy:**
> Clean steel lines. A precise rectangle of water. An acrylic window that turns the pool into a lightbox after dark. A Modpool doesn't decorate your property — it completes the composition.

**Facebook/Instagram primary text:**
> There are two kinds of pools. The kind you explain away — and the kind your architect photographs for their portfolio. A Modpool is the second kind: industrial steel refined into a precise, minimal form, with a glass viewing panel that makes the water part of the elevation. For homes where every line was a decision, this is the pool that belongs.

**Short version:**
> Steel. Glass. A precise rectangle of water. The pool that completes the composition.

**CTA:** *Explore The Design*

**Visual/video concept:** Architectural film language: locked-off symmetrical shots, morning light moving across steel, water surface like glass, one swimmer crossing the frame through the window. No music but ambient sound. Text, minimal serif: "Designed, not dug."

**5 Facebook headlines:**
1. Designed, Not Dug
2. The Pool Architects Choose
3. Geometry, Meet Water
4. A Lightbox After Dark
5. Complete The Composition

**5 Instagram captions:**
1. Designed, not dug.
2. The most architectural object in the yard.
3. Water as part of the elevation. 📐
4. Every line was a decision. Including this one.
5. The portfolio shot, from your kitchen window.

**5 Google headlines (≤30 char):**
1. Architectural Pools
2. Modern Minimal Pool Design
3. The Designer Container Pool
4. Steel & Glass Pools
5. Pools For Modern Homes

**5 Google descriptions (≤90 char):**
1. Precise steel geometry, acrylic windows, minimal form. The architectural pool.
2. The pool architects specify for modern homes. Explore Modpools design.
3. Clean lines, glass panel, glowing water. Designed, not dug.
4. A pool that completes the composition. See finishes & window options.
5. Industrial steel, refined. Modern pools for design-led homes.

**5 YouTube pre-roll hooks:**
1. "Your house has clean lines. Your pool shouldn't be a blob."
2. "Architects keep photographing this pool. Here's why."
3. "This is what happens when a pool is designed instead of dug."
4. "Steel, glass, and one very precise rectangle of water."
5. "The last object your property needed."

**5 TikTok hooks:**
1. "Telling my architect we bought a container pool and watching him relax."
2. "Design details in our pool that nobody asked for but everyone notices."
3. "It's giving lightbox." *(night window shot)*
4. "Blob pools could never." *(clean-line pan)*
5. "POV: your pool matches your house's energy."

**5 Pinterest headlines:**
1. Modern Architectural Pool Design
2. Minimalist Pool Ideas
3. Steel and Glass Pool Inspiration
4. Pools for Modern Homes
5. Designer Container Pool Aesthetics

---

# CAMPAIGN 10 — Summer Ready
### *"Summer Doesn't Wait"*

**Angle:** Seasonal urgency (honest scarcity). | **Emotional trigger:** Fear of another poolless summer. | **Pain point:** Every year they "look into it" in June — and it's too late again. | **Objection addressed:** "We'll do it next year." Next year is what you said last year.

**Scroll-stopping hook:**
> You said "next summer" last summer.

**Primary headline:**
> Order before the season does.

**Supporting copy:**
> Every spring, install calendars fill and another wave of families spends July "still deciding." A Modpool installs in days — but the queue is real. Start now and this is the summer the towels come out.

**Facebook/Instagram primary text:**
> Here's how the poolless summer happens: March, "we should really look into it." May, quotes and hesitation. July, it's hot, it's too late, and there's always next year. Break the loop. Because Modpools install in days, deciding now still means swimming soon — but install calendars fill fastest exactly when everyone remembers summer exists. This is the sign you were waiting for. It's warm out.

**Short version:**
> You said "next summer" last summer. Install calendars are filling. Break the loop.

**CTA:** *Reserve Your Install Window*

**Visual/video concept:** Calendar pages flip: "Next year." "Next year." "Next year." Hard cut: crane day, water filling, first jump. Freeze mid-splash. Text: "This year."

**5 Facebook headlines:**
1. You Said Next Summer Last Year
2. Order Before The Season Does
3. Break The Poolless Loop
4. This Is The Sign. It's Warm.
5. Install Windows Are Filling

**5 Instagram captions:**
1. You said "next summer" last summer. ☀️
2. Break the loop. Book the crane.
3. July-you is begging March-you to act.
4. The season books up. So do we.
5. This year. Finally, this year.

**5 Google headlines (≤30 char):**
1. Swim This Summer
2. Pool Installs Booking Now
3. Be Summer Ready
4. Reserve Your Install Window
5. Don't Wait Another Summer

**5 Google descriptions (≤90 char):**
1. Modpools install in days — but summer install windows fill fast. Start now.
2. Break the "next year" loop. Fast, factory-built pools, ready for summer.
3. Deciding now still means swimming soon. Reserve your install window.
4. Another summer without a pool? Not this one. Explore Modpools today.
5. Fast installation meets a filling calendar. Get your timeline now.

**5 YouTube pre-roll hooks:**
1. "Quick question: didn't you say this last summer?"
2. "The difference between a July pool and a July regret is this ad."
3. "Install calendars fill in spring. It's spring."
4. "This family decided in March. Watch their June."
5. "Skip the ad if you're okay with one more poolless summer."

**5 TikTok hooks:**
1. "March-me finally did what three previous Marches couldn't."
2. "POV: it's July and you actually have the pool this time."
3. "The 'we'll do it next year' streak ends now."
4. "Booking the install before the group chat plans the party."
5. "It's warm out. You know what that means." *(calendar flip)*

**5 Pinterest headlines:**
1. Get Summer-Ready: Backyard Pools
2. Fast Pool Ideas Before Summer
3. Summer Backyard Checklist
4. Pool Planning Timeline Tips
5. This Year's Backyard Project

---

# A/B TESTING PLAYBOOK

## Test 1 — Master angle bake-off (run first)
Same audience, same creative format, three ads:
- **TIME:** "Installed in days, not months." (Campaign 2 assets)
- **DESIGN:** "Designed, not dug." (Campaign 9 assets)
- **ACCESS:** "Your yard is big enough." (Campaign 5 assets)
Winner becomes your default cold-traffic angle. Expect TIME to win on clicks and DESIGN to win on lead quality — check both metrics before crowning.

## Test 2 — Hook style (within winning angle)
- **Curiosity:** "It was a WHAT?"
- **Pain-first:** "The quote made you close the laptop."
- **Identity:** "Become the house everyone swims at."

## Test 3 — Proof format
- Transformation video (container → pool) vs. static dusk beauty shot vs. install-day timelapse. Video usually wins reach; test whether stills win cost-per-lead on retargeting.

## Test 4 — CTA ladder
Cold traffic: *See The Transformation* / *See If Your Yard Fits* (low commitment).
Warm traffic: *Design Your Modpool* / *Get Your Install Timeline* (configurator intent).
Hot/retargeting: *Reserve Your Install Window* (urgency).
Test soft vs. direct CTA on cold audiences — soft usually lifts volume, direct lifts quality.

## Test 5 — Seasonal pressure
Run Campaign 10 (urgency) against Campaign 1 (aspiration) from Feb–May. Track whether honest scarcity beats pure aspiration as the season approaches; flip budget monthly.

## Hook banks (mix into any campaign)

**Curiosity:** "It crossed the ocean 40 times." · "There's a window in this pool." · "The build happened 400 miles from the backyard."
**Scarcity (honest):** "Install calendars fill by spring." · "Summer doesn't reschedule." · "The season books up. So do we."
**Luxury:** "Checkout time: never." · "The resort, relocated." · "Designed, not dug."
**ROI:** "Guests book pools." · "The amenity that shows up in search filters." · "Earning in shoulder season."
**Lifestyle:** "Become the pool house." · "The bikes on the lawn tell the story." · "The sound of summer, daily."

## Retargeting sequence (recommended)
1. **Day 0–3 after site visit:** Transformation video (Campaign 3) — re-spark the wow.
2. **Day 4–10:** Objection killers — small yard (5), fast install (2), year-round (4), matched to pages they viewed.
3. **Day 11+:** Urgency (10) with *Reserve Your Install Window*.

## Measurement notes
- Judge platforms by role: TikTok/YouTube = cheap attention and hook validation; Meta = lead volume; Google Search = high-intent capture (protect brand terms + "container pool," "small backyard pool," "pool installed fast").
- Track cost-per-qualified-lead, not cost-per-click — DESIGN-angle clicks are fewer but historically better-qualified in premium home categories.
- Refresh hooks every 3–4 weeks; keep winning structure, swap the opening line.

---

*Deck ends. Every claim traces to the brief's stated product facts; illustrative details (water temperatures, anecdotes) are creative color — set real numbers before trafficking. No pricing, revenue promises, or per-site guarantees included by design.*
